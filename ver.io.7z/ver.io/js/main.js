// Cache DOM elements for performance
const DOM = {
    serverWidget: null,
    serverName: null,
    statusIndicator: null,
    mapName: null,
    mapImage: null,
    gametype: null,
    playerCount: null,
    playerList: null,
    discordName: null,
    discordCount: null,
    discordMembers: null,
    discordInvite: null
};

// Initialize DOM cache
function initDOMCache() {
    DOM.serverWidget = document.getElementById('server-widget');
    DOM.serverName = document.getElementById('server-name');
    DOM.statusIndicator = document.getElementById('server-status-indicator');
    DOM.mapName = document.getElementById('map-name');
    DOM.mapImage = document.getElementById('map-image');
    DOM.gametype = document.getElementById('gametype');
    DOM.playerCount = document.getElementById('player-count');
    DOM.playerList = document.getElementById('player-list');
    DOM.discordName = document.getElementById('discord-server-name');
    DOM.discordCount = document.getElementById('discord-count');
    DOM.discordMembers = document.getElementById('discord-members');
    DOM.discordInvite = document.getElementById('discord-invite-link');
}

document.addEventListener('DOMContentLoaded', () => {
    initDOMCache();
    
    // Initial fetch
    fetchServerStatus();
    fetchDiscordStatus();
    
    // LIVE STATUS: Refresh every 10 seconds for real-time updates
    setInterval(fetchServerStatus, 10000);
    setInterval(fetchDiscordStatus, 60000); // Discord every 60s (rate limited)
});

async function fetchServerStatus() {
    const targetUrl = 'https://api.cod.pm/getstatus/54.37.73.239/28960';
    const apiUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(targetUrl)}`;
    
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);
        
        const response = await fetch(apiUrl, { signal: controller.signal });
        clearTimeout(timeoutId);
        
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        
        if (data.error === 0) {
            updateServerUI(data);
            if (DOM.serverWidget) DOM.serverWidget.classList.remove('loading');
        } else {
            handleError('server-name', 'Server Offline');
        }
    } catch (error) {
        if (error.name !== 'AbortError') {
            console.error('Error fetching server status:', error);
        }
    }
}

async function fetchDiscordStatus() {
    const guildId = '1148668356136800366'; 
    const apiUrl = `https://discord.com/api/guilds/${guildId}/widget.json`;

    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);
        
        const response = await fetch(apiUrl, { signal: controller.signal });
        clearTimeout(timeoutId);
        
        if (!response.ok) throw new Error('Discord API Error');

        const data = await response.json();
        updateDiscordUI(data);

    } catch (error) {
        if (error.name !== 'AbortError') {
            console.error('Error fetching Discord status:', error);
        }
        if (DOM.discordName) DOM.discordName.textContent = 'Verindra Clan';
    }
}

function updateDiscordUI(data) {
    if (DOM.discordName) DOM.discordName.textContent = data.name || 'Verindra Clan';
    if (DOM.discordCount) DOM.discordCount.textContent = data.presence_count || 0;
    
    if (DOM.discordInvite && data.instant_invite) {
        DOM.discordInvite.href = data.instant_invite;
    }

    if (!DOM.discordMembers) return;
    
    // Use DocumentFragment for batch DOM updates
    const fragment = document.createDocumentFragment();

    if (data.members && data.members.length > 0) {
        data.members.forEach(member => {
            const statusColor = member.status === 'online' ? '#43b581' : 
                               member.status === 'idle' ? '#faa61a' : 
                               member.status === 'dnd' ? '#f04747' : '#747f8d';
            
            const div = document.createElement('div');
            div.className = 'discord-member';
            div.innerHTML = `
                <div class="member-avatar">
                    <img src="${member.avatar_url}" alt="" loading="lazy" width="36" height="36">
                    <span class="status-dot" style="background-color: ${statusColor}"></span>
                </div>
                <div class="member-info">
                    <span class="member-name">${member.username}</span>
                    ${member.game ? `<span class="member-game">${member.game.name}</span>` : ''}
                </div>
            `;
            fragment.appendChild(div);
        });
    } else {
        const p = document.createElement('p');
        p.className = 'no-members';
        p.textContent = 'No members online';
        fragment.appendChild(p);
    }
    
    DOM.discordMembers.innerHTML = '';
    DOM.discordMembers.appendChild(fragment);
}

function updateServerUI(data) {
    const info = data.serverinfo;
    const players = data.playerinfo || [];
    
    // Update status indicator
    if (DOM.statusIndicator) {
        DOM.statusIndicator.classList.remove('offline');
        DOM.statusIndicator.classList.add('online');
    }
    
    // Update Server Name (Parse color codes)
    if (DOM.serverName) {
        DOM.serverName.innerHTML = parseColorCodes(info.sv_hostname || 'Unknown Server');
        DOM.serverName.style.color = '';
    }
    
    // Update Map
    const mapName = info.mapname || 'mp_toujane';
    if (DOM.mapName) DOM.mapName.textContent = mapName;
    
    // Update Map Image
    if (DOM.mapImage) {
        const newSrc = `https://cod.pm/mp_maps/cod2/stock/${mapName}.png`;
        if (DOM.mapImage.src !== newSrc) {
            DOM.mapImage.src = newSrc;
            DOM.mapImage.onerror = function() {
                this.src = 'https://cod.pm/mp_maps/cod2/stock/mp_toujane.png';
            };
        }
    }
    
    // Update Gametype
    const gametypeMap = {
        'ctf': 'Capture the Flag',
        'sd': 'Search & Destroy',
        'dm': 'Deathmatch',
        'tdm': 'Team Deathmatch',
        'hq': 'Headquarters',
        'dom': 'Domination',
        'koth': 'King of the Hill'
    };
    const gametype = info.g_gametype || 'Unknown';
    if (DOM.gametype) DOM.gametype.textContent = gametypeMap[gametype] || gametype.toUpperCase();
    
    // Update Player Count
    const maxClients = info.sv_maxclients || '48';
    if (DOM.playerCount) DOM.playerCount.textContent = `${players.length} / ${maxClients}`;
    
    // Update Player Table using DocumentFragment
    if (!DOM.playerList) return;
    
    const fragment = document.createDocumentFragment();
    
    if (players.length === 0) {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td colspan="3" class="no-players">No players online</td>';
        fragment.appendChild(tr);
    } else {
        players.forEach(player => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="player-name">${parseColorCodes(player.name)}</td>
                <td class="player-score">${player.score}</td>
                <td class="player-ping">${player.ping}</td>
            `;
            fragment.appendChild(tr);
        });
    }
    
    DOM.playerList.innerHTML = '';
    DOM.playerList.appendChild(fragment);
}

function handleError(elementId, message) {
    if (DOM.serverName) {
        DOM.serverName.textContent = message || 'Offline';
        DOM.serverName.style.color = 'var(--secondary-color)';
    }
    
    if (DOM.statusIndicator) {
        DOM.statusIndicator.classList.remove('online');
        DOM.statusIndicator.classList.add('offline');
    }
}

function parseColorCodes(text) {
    if (!text) return '';
    
    // Map CoD color codes to CSS classes or hex values
    // ^1: Red, ^2: Green, ^3: Yellow, ^4: Blue, ^5: Cyan, ^6: Pink, ^7: White, ^0: Black
    const colors = {
        '1': '#FF3333', // Red
        '2': '#33FF33', // Green
        '3': '#FFFF33', // Yellow
        '4': '#3333FF', // Blue
        '5': '#00E5FF', // Cyan
        '6': '#FF33FF', // Pink
        '7': '#FFFFFF', // White
        '0': '#000000', // Black
        '8': '#bbbbbb', // Grey (Map default)
        '9': '#bbbbbb'  // Grey
    };

    let html = '';
    let currentColor = '#FFFFFF'; // Default white
    let parts = text.split('^');
    
    // Handle the first part (before any color code)
    if (parts[0]) {
        html += `<span style="color: ${currentColor}">${parts[0]}</span>`;
    }

    for (let i = 1; i < parts.length; i++) {
        let part = parts[i];
        if (part.length === 0) continue;

        const colorCode = part.charAt(0);
        const content = part.substring(1);

        if (colors[colorCode]) {
            currentColor = colors[colorCode];
        }
        // If color code is invalid, we just treat it as text (or keep previous color)
        // But usually in CoD, ^ followed by non-digit is literal. 
        // For simplicity, we assume valid codes update color.
        
        if (content) {
            html += `<span style="color: ${currentColor}">${content}</span>`;
        }
    }

    return html;
}

function copyIP() {
    const ip = '54.37.73.239:28960';
    navigator.clipboard.writeText(ip).then(() => {
        alert('IP copied to clipboard: ' + ip + '\n\nOpen console (~) in-game and type:\n/connect ' + ip);
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
}
