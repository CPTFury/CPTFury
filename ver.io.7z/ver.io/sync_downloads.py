#!/usr/bin/env python3
"""
VERINDRA - Download Page Generator
Generates an nginx-style directory listing for game downloads hosted on Cloudflare R2.

Features:
- Multi-folder support with hierarchical display
- File size formatting
- Incremental updates using JSON cache
- Generates responsive HTML with folder navigation
"""

import os
import json
import hashlib
from datetime import datetime
from pathlib import Path
from typing import TypedDict, Optional

# =============================================================================
# Configuration
# =============================================================================
class Config:
    """Configuration settings for the download sync tool."""
    
    # Cloudflare R2 base URL
    R2_BASE_URL = "https://pub-887a3c20db774fdc88337e22287d59a3.r2.dev"
    
    # Local paths (relative to script location)
    DOWNLOADS_DIR = "downloads"
    OUTPUT_FILE = "downloads.html"
    CACHE_FILE = "downloads_data.json"
    
    # File extensions to include
    ALLOWED_EXTENSIONS = {
        '.iwd', '.pk3', '.ff', '.zip', '.rar', '.7z',
        '.exe', '.dll', '.cfg', '.txt', '.md'
    }


# =============================================================================
# Type Definitions
# =============================================================================
class FileInfo(TypedDict):
    """Type definition for file information."""
    name: str
    path: str
    size: int
    size_formatted: str
    url: str
    hash: str


class FolderInfo(TypedDict):
    """Type definition for folder information."""
    name: str
    path: str
    files: list[FileInfo]
    subfolders: list['FolderInfo']


class CacheData(TypedDict):
    """Type definition for cache data structure."""
    version: str
    generated_at: str
    folders: list[FolderInfo]


# =============================================================================
# Utility Functions
# =============================================================================
def format_file_size(size_bytes: int) -> str:
    """
    Format file size in human-readable format.
    
    Args:
        size_bytes: File size in bytes
        
    Returns:
        Formatted string (e.g., "1.5 MB", "256 KB")
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 ** 3:
        return f"{size_bytes / (1024 ** 2):.1f} MB"
    else:
        return f"{size_bytes / (1024 ** 3):.2f} GB"


def calculate_file_hash(filepath: Path) -> str:
    """
    Calculate MD5 hash of file for change detection.
    Uses partial read for large files.
    
    Args:
        filepath: Path to the file
        
    Returns:
        MD5 hash string
    """
    hasher = hashlib.md5()
    
    with open(filepath, 'rb') as f:
        # Read first and last 64KB for large files
        chunk = f.read(65536)
        hasher.update(chunk)
        
        file_size = filepath.stat().st_size
        if file_size > 131072:  # 128KB
            f.seek(-65536, 2)  # Seek to last 64KB
            chunk = f.read(65536)
            hasher.update(chunk)
        
        # Include file size in hash
        hasher.update(str(file_size).encode())
    
    return hasher.hexdigest()[:12]


def get_file_icon(filename: str) -> str:
    """
    Get appropriate Font Awesome icon class for file type.
    
    Args:
        filename: Name of the file
        
    Returns:
        Font Awesome icon class
    """
    ext = Path(filename).suffix.lower()
    icons = {
        '.iwd': 'fa-file-archive',
        '.pk3': 'fa-file-archive',
        '.zip': 'fa-file-archive',
        '.rar': 'fa-file-archive',
        '.7z': 'fa-file-archive',
        '.exe': 'fa-file-code',
        '.dll': 'fa-cog',
        '.cfg': 'fa-file-alt',
        '.txt': 'fa-file-alt',
        '.md': 'fa-file-alt',
        '.ff': 'fa-file',
    }
    return icons.get(ext, 'fa-file')


# =============================================================================
# Scanner Class
# =============================================================================
class DownloadScanner:
    """Scans download directories and builds file structure."""
    
    def __init__(self, base_dir: Path):
        """
        Initialize the scanner.
        
        Args:
            base_dir: Base directory containing download folders
        """
        self.base_dir = base_dir
    
    def scan(self) -> list[FolderInfo]:
        """
        Scan all folders in the downloads directory.
        
        Returns:
            List of folder information dictionaries
        """
        folders: list[FolderInfo] = []
        
        if not self.base_dir.exists():
            print(f"Warning: Downloads directory not found: {self.base_dir}")
            return folders
        
        # Get all directories
        for item in sorted(self.base_dir.iterdir()):
            if item.is_dir() and not item.name.startswith('.'):
                folder_info = self._scan_folder(item, item.name)
                if folder_info['files'] or folder_info['subfolders']:
                    folders.append(folder_info)
        
        return folders
    
    def _scan_folder(self, folder_path: Path, relative_path: str) -> FolderInfo:
        """
        Recursively scan a folder and its contents.
        
        Args:
            folder_path: Absolute path to the folder
            relative_path: Path relative to downloads directory
            
        Returns:
            FolderInfo dictionary
        """
        folder_info: FolderInfo = {
            'name': folder_path.name,
            'path': relative_path,
            'files': [],
            'subfolders': []
        }
        
        for item in sorted(folder_path.iterdir()):
            if item.name.startswith('.'):
                continue
            
            if item.is_file():
                if item.suffix.lower() in Config.ALLOWED_EXTENSIONS:
                    file_info = self._get_file_info(item, relative_path)
                    folder_info['files'].append(file_info)
            
            elif item.is_dir():
                subfolder_path = f"{relative_path}/{item.name}"
                subfolder_info = self._scan_folder(item, subfolder_path)
                if subfolder_info['files'] or subfolder_info['subfolders']:
                    folder_info['subfolders'].append(subfolder_info)
        
        return folder_info
    
    def _get_file_info(self, filepath: Path, folder_path: str) -> FileInfo:
        """
        Get information about a file.
        
        Args:
            filepath: Path to the file
            folder_path: Parent folder path
            
        Returns:
            FileInfo dictionary
        """
        size = filepath.stat().st_size
        url_path = f"{folder_path}/{filepath.name}".replace('\\', '/')
        
        return {
            'name': filepath.name,
            'path': url_path,
            'size': size,
            'size_formatted': format_file_size(size),
            'url': f"{Config.R2_BASE_URL}/{url_path}",
            'hash': calculate_file_hash(filepath)
        }


# =============================================================================
# HTML Generator Class
# =============================================================================
class HTMLGenerator:
    """Generates the downloads HTML page."""
    
    def __init__(self, folders: list[FolderInfo]):
        """
        Initialize the generator.
        
        Args:
            folders: List of folder information
        """
        self.folders = folders
    
    def generate(self) -> str:
        """
        Generate the complete HTML page.
        
        Returns:
            Complete HTML string
        """
        total_files = self._count_files(self.folders)
        total_size = self._sum_sizes(self.folders)
        
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Verindra CoD2 - Game file downloads including maps, mods, and patches">
    <title>Downloads - Verindra CoD2</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Downloads Page Specific Styles */
        .downloads-header {{
            padding: calc(var(--header-height) + var(--space-xl)) var(--space-md) var(--space-lg);
            text-align: center;
            background: linear-gradient(to bottom, #1a2a3a 0%, var(--color-bg-dark) 100%);
        }}
        
        .downloads-header h1 {{
            font-size: clamp(1.5rem, 4vw, 2.5rem);
            margin-bottom: var(--space-sm);
        }}
        
        .downloads-stats {{
            display: flex;
            justify-content: center;
            gap: var(--space-lg);
            margin-top: var(--space-md);
            color: var(--color-text-muted);
        }}
        
        .downloads-stats span {{
            display: flex;
            align-items: center;
            gap: var(--space-sm);
        }}
        
        .downloads-container {{
            max-width: 1000px;
            margin: 0 auto;
            padding: var(--space-lg) var(--space-md);
        }}
        
        .folder {{
            margin-bottom: var(--space-lg);
            background: var(--color-bg-card);
            border: 1px solid var(--color-border);
            border-radius: var(--border-radius);
            overflow: hidden;
        }}
        
        .folder__header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: var(--space-md);
            background: rgba(0, 0, 0, 0.3);
            cursor: pointer;
            user-select: none;
            transition: background var(--transition-fast);
        }}
        
        .folder__header:hover {{
            background: rgba(0, 0, 0, 0.5);
        }}
        
        .folder__name {{
            display: flex;
            align-items: center;
            gap: var(--space-sm);
            font-family: var(--font-heading);
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--color-primary);
        }}
        
        .folder__name i {{
            color: var(--color-secondary);
        }}
        
        .folder__toggle {{
            color: var(--color-text-muted);
            transition: transform var(--transition-base);
        }}
        
        .folder.is-collapsed .folder__toggle {{
            transform: rotate(-90deg);
        }}
        
        .folder__content {{
            border-top: 1px solid var(--color-border);
        }}
        
        .folder.is-collapsed .folder__content {{
            display: none;
        }}
        
        .subfolder {{
            margin: var(--space-md);
            background: rgba(0, 0, 0, 0.2);
            border-radius: var(--border-radius);
            overflow: hidden;
        }}
        
        .subfolder__header {{
            display: flex;
            align-items: center;
            gap: var(--space-sm);
            padding: var(--space-sm) var(--space-md);
            background: rgba(0, 0, 0, 0.2);
            font-family: var(--font-heading);
            color: var(--color-text-muted);
        }}
        
        .file-table {{
            width: 100%;
            border-collapse: collapse;
        }}
        
        .file-table th,
        .file-table td {{
            padding: var(--space-sm) var(--space-md);
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }}
        
        .file-table th {{
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--color-text-muted);
            background: rgba(0, 0, 0, 0.3);
        }}
        
        .file-table tr:hover {{
            background: rgba(255, 255, 255, 0.02);
        }}
        
        .file-link {{
            display: flex;
            align-items: center;
            gap: var(--space-sm);
            color: var(--color-text);
            transition: color var(--transition-fast);
        }}
        
        .file-link:hover {{
            color: var(--color-primary);
        }}
        
        .file-link i {{
            color: var(--color-secondary);
            width: 1.2em;
        }}
        
        .file-size {{
            color: var(--color-text-muted);
            font-size: 0.9rem;
            white-space: nowrap;
        }}
        
        .download-btn {{
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            background: var(--color-primary);
            color: #000;
            border-radius: 4px;
            transition: background var(--transition-fast);
        }}
        
        .download-btn:hover {{
            background: #fff;
        }}
        
        .empty-folder {{
            padding: var(--space-lg);
            text-align: center;
            color: var(--color-text-muted);
        }}
        
        .breadcrumb {{
            display: flex;
            align-items: center;
            gap: var(--space-xs);
            padding: var(--space-md);
            font-size: 0.9rem;
            color: var(--color-text-muted);
            background: rgba(0, 0, 0, 0.2);
            border-bottom: 1px solid var(--color-border);
        }}
        
        .breadcrumb a {{
            color: var(--color-primary);
        }}
        
        .breadcrumb a:hover {{
            text-decoration: underline;
        }}
        
        @media (max-width: 600px) {{
            .file-table th:last-child,
            .file-table td:last-child {{
                display: none;
            }}
            
            .downloads-stats {{
                flex-direction: column;
                gap: var(--space-sm);
            }}
        }}
    </style>
</head>
<body>
    <!-- Header -->
    <header class="site-header">
        <div class="container">
            <a href="index.html" class="logo">
                <span class="cyan">VER</span><span class="red">INDRA</span>
            </a>
            <nav class="nav-menu" aria-label="Main navigation">
                <a href="index.html">Home</a>
                <a href="index.html#server">Server</a>
                <a href="downloads.html" aria-current="page">Downloads</a>
                <a href="index.html#faq">FAQ</a>
                <a href="index.html#discord">Discord</a>
            </nav>
            <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </header>

    <!-- Downloads Header -->
    <section class="downloads-header">
        <h1><i class="fas fa-download"></i> <span class="cyan">Downloads</span></h1>
        <p>Game files, maps, mods, and patches for Verindra CoD2 servers</p>
        <div class="downloads-stats">
            <span><i class="fas fa-file"></i> {total_files} files</span>
            <span><i class="fas fa-hdd"></i> {format_file_size(total_size)} total</span>
        </div>
    </section>

    <!-- Downloads Content -->
    <main class="downloads-container">
        {self._render_folders()}
    </main>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="container">
            <p>&copy; {datetime.now().year} Verindra - Call of Duty 2 Community</p>
            <a href="https://discord.gg/z2f5VUVQ3J" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="Join our Discord">
                <i class="fab fa-discord"></i>
            </a>
        </div>
    </footer>

    <script>
        // Toggle folder collapse
        document.querySelectorAll('.folder__header').forEach(header => {{
            header.addEventListener('click', () => {{
                header.parentElement.classList.toggle('is-collapsed');
            }});
        }});
        
        // Mobile navigation
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (navToggle && navMenu) {{
            navToggle.addEventListener('click', () => {{
                navMenu.classList.toggle('is-active');
                navToggle.setAttribute('aria-expanded', navMenu.classList.contains('is-active'));
            }});
        }}
    </script>
</body>
</html>"""
    
    def _render_folders(self) -> str:
        """Render all folders as HTML."""
        if not self.folders:
            return '<div class="empty-folder"><i class="fas fa-folder-open"></i> No downloads available</div>'
        
        html_parts = []
        for folder in self.folders:
            html_parts.append(self._render_folder(folder))
        
        return '\n'.join(html_parts)
    
    def _render_folder(self, folder: FolderInfo) -> str:
        """Render a single folder as HTML."""
        file_count = len(folder['files'])
        for sub in folder['subfolders']:
            file_count += len(sub['files'])
        
        content_html = ''
        
        # Render files in root of this folder
        if folder['files']:
            content_html += self._render_file_table(folder['files'])
        
        # Render subfolders
        for subfolder in folder['subfolders']:
            content_html += self._render_subfolder(subfolder)
        
        if not content_html:
            content_html = '<div class="empty-folder">This folder is empty</div>'
        
        return f"""
        <div class="folder">
            <div class="folder__header">
                <div class="folder__name">
                    <i class="fas fa-folder"></i>
                    {folder['name']}
                    <span style="color: var(--color-text-muted); font-weight: 400; font-size: 0.9rem;">
                        ({file_count} files)
                    </span>
                </div>
                <i class="fas fa-chevron-down folder__toggle"></i>
            </div>
            <div class="folder__content">
                {content_html}
            </div>
        </div>"""
    
    def _render_subfolder(self, folder: FolderInfo) -> str:
        """Render a subfolder as HTML."""
        html = f"""
        <div class="subfolder">
            <div class="subfolder__header">
                <i class="fas fa-folder-open"></i>
                {folder['name']}
                <span style="margin-left: auto;">({len(folder['files'])} files)</span>
            </div>
            {self._render_file_table(folder['files']) if folder['files'] else '<div class="empty-folder">Empty</div>'}
        </div>"""
        
        # Recursively render nested subfolders
        for sub in folder['subfolders']:
            html += self._render_subfolder(sub)
        
        return html
    
    def _render_file_table(self, files: list[FileInfo]) -> str:
        """Render a file table as HTML."""
        rows = []
        for f in files:
            icon = get_file_icon(f['name'])
            rows.append(f"""
                <tr>
                    <td>
                        <a href="{f['url']}" class="file-link" download>
                            <i class="fas {icon}"></i>
                            {f['name']}
                        </a>
                    </td>
                    <td class="file-size">{f['size_formatted']}</td>
                    <td>
                        <a href="{f['url']}" class="download-btn" download title="Download">
                            <i class="fas fa-download"></i>
                        </a>
                    </td>
                </tr>""")
        
        return f"""
            <table class="file-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Size</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(rows)}
                </tbody>
            </table>"""
    
    def _count_files(self, folders: list[FolderInfo]) -> int:
        """Count total files in folder structure."""
        count = 0
        for folder in folders:
            count += len(folder['files'])
            count += self._count_files(folder['subfolders'])
        return count
    
    def _sum_sizes(self, folders: list[FolderInfo]) -> int:
        """Sum total size of all files."""
        total = 0
        for folder in folders:
            total += sum(f['size'] for f in folder['files'])
            total += self._sum_sizes(folder['subfolders'])
        return total


# =============================================================================
# Cache Manager Class
# =============================================================================
class CacheManager:
    """Manages the JSON cache for incremental updates."""
    
    def __init__(self, cache_path: Path):
        """
        Initialize the cache manager.
        
        Args:
            cache_path: Path to the cache file
        """
        self.cache_path = cache_path
    
    def load(self) -> Optional[CacheData]:
        """Load cache from file."""
        if not self.cache_path.exists():
            return None
        
        try:
            with open(self.cache_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Could not load cache: {e}")
            return None
    
    def save(self, folders: list[FolderInfo]) -> None:
        """Save cache to file."""
        cache_data: CacheData = {
            'version': '2.0',
            'generated_at': datetime.now().isoformat(),
            'folders': folders
        }
        
        with open(self.cache_path, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, indent=2)
    
    def needs_update(self, current_folders: list[FolderInfo]) -> bool:
        """Check if cache needs to be updated."""
        cached = self.load()
        
        if not cached:
            return True
        
        # Compare folder structure
        return self._hash_folders(current_folders) != self._hash_folders(cached.get('folders', []))
    
    def _hash_folders(self, folders: list) -> str:
        """Generate hash of folder structure for comparison."""
        def extract_hashes(folder_list: list) -> list:
            hashes = []
            for folder in folder_list:
                for f in folder.get('files', []):
                    hashes.append(f.get('hash', ''))
                hashes.extend(extract_hashes(folder.get('subfolders', [])))
            return sorted(hashes)
        
        return hashlib.md5(''.join(extract_hashes(folders)).encode()).hexdigest()


# =============================================================================
# Main Entry Point
# =============================================================================
def main():
    """Main entry point for the script."""
    # Determine paths
    script_dir = Path(__file__).parent.resolve()
    downloads_dir = script_dir / Config.DOWNLOADS_DIR
    output_file = script_dir / Config.OUTPUT_FILE
    cache_file = script_dir / Config.CACHE_FILE
    
    print(f"Scanning downloads: {downloads_dir}")
    
    # Scan downloads directory
    scanner = DownloadScanner(downloads_dir)
    folders = scanner.scan()
    
    # Check cache
    cache = CacheManager(cache_file)
    if not cache.needs_update(folders):
        print("No changes detected. Skipping regeneration.")
        return
    
    # Generate HTML
    generator = HTMLGenerator(folders)
    html = generator.generate()
    
    # Write output
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html)
    
    # Update cache
    cache.save(folders)
    
    # Summary
    total_files = generator._count_files(folders)
    total_size = generator._sum_sizes(folders)
    
    print(f"\n✓ Generated: {output_file}")
    print(f"  Folders: {len(folders)}")
    print(f"  Files: {total_files}")
    print(f"  Total Size: {format_file_size(total_size)}")


if __name__ == '__main__':
    main()
