# Verindra Clan - Call of Duty 2 Server Website

Modern, responsive website for the Verindra Call of Duty 2 gaming clan. Features live server status, Discord integration, and file downloads via Cloudflare R2.

## Features

- **Live Server Status** - Real-time player count and map info via cod.pm API
- **Discord Widget** - Shows online members and server invite
- **Custom Downloads** - Browse and download 27+ custom maps
- **Protocol Handler** - "Connect Now" button launches CoD2 directly
- **FAQ Guides** - Installation guides for CoD2x, game setup, and performance fixes
- **Responsive Design** - Works on desktop and mobile

---

## File Structure

```
ver.io/
├── index.html              # Main homepage
├── downloads.html          # Auto-generated downloads page
├── sync_downloads.py       # Script to sync downloads
├── downloads_data.json     # Stores file metadata (auto-created)
├── css/
│   ├── style.css          # Main styles
│   └── faq.css            # FAQ section styles
├── js/
│   └── main.js            # Server status & Discord widget
├── files/
│   └── cod2-connect-setup.bat  # Protocol handler setup
└── downloads/
    └── verindramod/       # Put your .iwd map files here
```

---

## Managing Downloads

### Add New Maps

1. **Put your .iwd files** in `downloads/verindramod/`
2. **Run the sync script:**
   ```bash
   python sync_downloads.py
   ```
3. **Upload to Cloudflare R2** (same folder structure: `verindramod/filename.iwd`)
4. **Commit & push:**
   ```bash
   git add .
   git commit -m "Added new maps"
   git push
   ```

### Add Only New Maps (Keep Existing)

If you want to add new maps without rescanning everything:
```bash
python sync_downloads.py --add
```

This keeps existing file data and only adds new ones.

### Update Existing Map

1. Replace the file in `downloads/verindramod/`
2. Run: `python sync_downloads.py` (full sync)
3. Upload to R2
4. Commit & push

---

## Adding a New Mod Folder

Want to add a different mod (e.g., `awmod` or `custommod`)?

1. **Create folder:** `downloads/awmod/`
2. **Put .iwd files** inside it
3. **Run:** `python sync_downloads.py`

The script will **scan ALL folders** inside `downloads/` and generate the HTML with:
- A **folder header** for each mod (e.g., `verindramod/`, `awmod/`)
- **Separate installation paths** for each folder

**Example structure:**
```
downloads/
├── verindramod/
│   ├── mp_crash.iwd
│   └── mp_harbor.iwd
└── awmod/
    ├── map1.iwd
    └── map2.iwd
```

**Result:** Downloads page will show both folders with their files!

---

## Cloudflare R2 Setup

Your R2 bucket structure should match:
```
verindra-fastdl/
└── verindramod/
    ├── mp_breakout_tls.iwd
    ├── mp_crossroads.iwd
    └── ...
```

**Public URL format:**
```
https://pub-887a3c20db774fdc88337e22287d59a3.r2.dev/verindramod/filename.iwd
```

### Uploading to R2

1. Go to Cloudflare Dashboard → R2 → `verindra-fastdl`
2. Navigate to `verindramod/` folder
3. Click "Upload" and select your .iwd files
4. Files are instantly available via the public URL

---

## Editing the Site

### Update Server IP
Edit `js/main.js` line ~3:
```javascript
const targetUrl = 'https://api.cod.pm/getstatus/YOUR_IP/YOUR_PORT';
```

### Update Discord Server
Edit `js/main.js`:
```javascript
const guildId = 'YOUR_DISCORD_SERVER_ID';
```

### Change R2 URL
Edit `sync_downloads.py`:
```python
R2_BASE_URL = 'https://your-r2-url.r2.dev'
```

---

## Quick Reference

| Task | Command |
|------|---------|
| Sync all maps | `python sync_downloads.py` |
| Add new maps only | `python sync_downloads.py --add` |
| Test locally | Use VS Code Live Server |
| Deploy | `git push` (GitHub Pages auto-deploys) |

---

## Troubleshooting

### "No mod folders found"
Create the folder: `downloads/verindramod/`

### Downloads page shows wrong sizes
Run full sync: `python sync_downloads.py`

### Links not working
1. Check R2 bucket has the files
2. Verify folder name matches (`verindramod`)
3. Check file names match exactly (case-sensitive)

### Server status not updating
- Check if server is online at cod.pm
- API may be temporarily down
- Check browser console for errors

---

## Deployment

This site uses **GitHub Pages** for hosting. Simply push to the main branch and it auto-deploys.

```bash
git push origin main
```

The site will be live at: https://nawaftahir.github.io/verindra.github.io
